# 🇧🇷 BRASIL SEGURO

Projeto de site com Inteligência Artificial voltado ao monitoramento preventivo
e alerta de possíveis indícios de uso indevido de CPF.

## Conteúdo do repositório
- BRASIL_SEGURO_PROMPT.txt → Prompt oficial para z.ai
- README.md → Documentação do projeto

## Aviso Legal
Este serviço é preventivo e informativo, não sendo banco, órgão público
ou birô de crédito.
